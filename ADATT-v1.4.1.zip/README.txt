========================================
  ADATT - Active Directory + Azure/M365 
  Termination Tool
  Version 1.4.0
========================================

WELCOME!

Thank you for trying ADATT! This professional tool automates user termination 
across Active Directory and Microsoft 365, including:

� Single user termination with auto-reply setup
� Bulk offboarding (up to 100 users)
� MFA reset
� Session sign-out
� Manager auto-population
� Detailed audit logging and CSV reports

========================================
TRIAL & PRICING
========================================

14-DAY FREE TRIAL - Full Features Unlocked

After trial, choose lifetime access:

� LAUNCH20 DISCOUNT ACTIVE:
   � Solo: $175 (1 device)
   � Team: $599 (5 devices)
   � Business: $999 (20 devices)

� ROI: Saves $272.50 per termination vs manual processing
   Break-even after just 1 termination!

========================================
*** FIRST TIME SETUP (REQUIRED) ***
========================================

Before running ADATT for the first time:

1. Right-click on PowerShell and select "Run as Administrator"
2. Run this command to allow PowerShell scripts:
   
   Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
   
3. Type "Y" and press Enter to confirm

This is a one-time setup required by Windows security.

========================================
QUICK START
========================================

1. Extract all files to a folder (e.g., C:\ADATT)
2. Complete "FIRST TIME SETUP" above (if you haven't already)
3. Right-click ADATT-UX.ps1 and select "Run with PowerShell"
4. Click "Activate License" when prompted
5. Enter your license key from your purchase email
6. Start using ADATT!

========================================
SYSTEM REQUIREMENTS
========================================

� Windows 10/11 or Windows Server 2016+
� PowerShell 5.1 or later
� Active Directory PowerShell module (RSAT)
� Internet connection (for license activation)
� Microsoft Graph PowerShell SDK (optional, for M365 features)
� Exchange Online Management module (optional, for mailbox features)

========================================
LICENSE ACTIVATION
========================================

Your license key was sent to your email after purchase.
Format: XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX

License Types:
� Solo Admin: 1 device
� Team: 5 devices  
� Business: 20 devices

You can activate ADATT on multiple devices based on your license type.
To deactivate from one device and move to another, use the deactivation 
feature in ADATT settings.

========================================
TRIAL MODE
========================================

ADATT includes a 14-day trial period. During the trial:
� All features are fully functional
� No credit card required
� Trial automatically activates on first run

After the trial expires, you'll need to activate a license to continue using ADATT.

========================================
FEATURES
========================================

SINGLE USER TERMINATION:
� Disable Active Directory account
� Convert mailbox to shared
� Set auto-reply message
� Auto-populate manager contact info
� Clear device registrations
� Remove MFA methods

BULK OFFBOARDING:
� Process 2-100 users from CSV/TXT file
� Real-time preview with AD validation
� Progress tracking with detailed status
� Automatic CSV report generation
� Skip already-disabled accounts

MFA RESET:
� Remove all authentication methods
� Phone, authenticator app, FIDO2 keys
� Windows Hello for Business
� Software OATH tokens

SESSION MANAGEMENT:
� Sign out users from all M365 sessions
� Force re-authentication on all devices

========================================
GETTING HELP
========================================

For installation help, see INSTALLATION_GUIDE.txt

For detailed usage instructions, click the "Help" button in ADATT.

Website: https://adatt.lemonsqueezy.com

========================================
VERSION HISTORY
========================================

Version 1.4.0 (December 2025)
� Changed trial period from 30 days to 14 days
� Added lifetime pricing model with LAUNCH20 discount
� Implemented soft lock for trial expiry (UI remains accessible)
� Added trial expired banner with activation instructions
� Updated to LemonSqueezy store URLs
� Improved post-trial user experience

Version 1.3.0 (December 2025)
� Enhanced UI with bold labels
� Increased bulk limit to 100 users
� Added example text to input fields
� Improved field alignment and spacing
� Fixed bulk termination reset logic
� Added form closing confirmation
� Real Active Directory integration
� License button auto-hide after activation

========================================
LICENSE
========================================

Copyright (c) 2025 Jose Ernest / Unifosec
Licensed to: [Customer Name from LemonSqueezy]

This software is licensed, not sold. See LICENSE.txt for full terms.

========================================
