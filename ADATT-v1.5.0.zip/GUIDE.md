# 📖 ADATT Usage Guide v1.5.0

Complete guide for using ADATT (Active Directory + Azure/M365 Termination Tool)

---

## 📑 Table of Contents

1. [Getting Started](#getting-started)
2. [Single User Termination](#single-user-termination)
3. [Bulk Termination](#bulk-termination)
4. [Reset MFA](#reset-mfa)
5. [Sign Out Sessions](#sign-out-sessions)
6. [Account Types](#account-types)
7. [Reports and Logs](#reports-and-logs)
8. [Best Practices](#best-practices)
9. [Troubleshooting](#troubleshooting)

---

## 🚀 Getting Started

### Launching ADATT
```powershell
# Navigate to installation folder
cd "C:\Program Files\ADATT"

# Launch application
.\ADATT-UX.ps1
```

### First-Time Setup
1. **License Activation**: Click "Activate License" → Enter key or start trial
2. **Graph Authentication**: First cloud operation prompts for Microsoft 365 login
3. **Exchange Connection**: First mailbox operation prompts for Exchange admin credentials

---

## 👤 Single User Termination

### Basic Termination Flow

#### Step 1: Enter Username
In the **"Single Termination"** section:
- **Field**: "sAMAccountName or UPN"
- **Accepted Formats**:
  - `john.doe` (sAMAccountName - for hybrid/on-premises users)
  - `john.doe@contoso.com` (UPN - for cloud-only or hybrid users)
  - `john.doe@contoso.onmicrosoft.com` (Cloud-only UPN)

#### Step 2: Click "Terminate"
ADATT performs automatic detection:
- Searches Active Directory (if hybrid/on-premises)
- Falls back to Entra ID (if cloud-only)
- Displays confirmation dialog with:
  - User's display name
  - Account type (Cloud-Only, Hybrid, On-Premises)
  - Operations that will be performed

#### Step 3: Review Confirmation
**Confirmation Dialog Shows**:
```
Terminate User: John Doe
Account Type: Hybrid
UPN: john.doe@contoso.com

Operations that will be performed:
✓ Disable AD account
✓ Reset AD password
✓ Clear manager field
✓ Add termination date to description
✓ Move to Disabled OU
✓ Disable Entra ID account
✓ Revoke all sessions
✓ Remove group memberships
✓ Remove assigned licenses
✓ Remove registered apps/devices
✓ Set mailbox Out-of-Office
✓ Convert to shared mailbox

Continue?
```

#### Step 4: Confirm or Cancel
- **Click "Yes, Terminate"**: Executes all operations
- **Click "Cancel"**: Aborts operation (no changes made)

### Operations Performed

#### Active Directory (Hybrid/On-Premises Only)
1. **Disable Account**: Sets `Enabled = $false`
2. **Reset Password**: Generates secure random password
3. **Clear Manager**: Removes manager reference
4. **Add Description**: Appends "Terminated on [Date]"
5. **Move to OU**: Relocates to "Disabled Users" OU
6. **Remove Groups**: Clears all group memberships (except Domain Users)

#### Microsoft Entra ID (Cloud-Only/Hybrid)
1. **Disable Account**: Sets `AccountEnabled = $false`
2. **Revoke Sessions**: Signs out all active sessions
3. **Block Sign-In**: Prevents future authentication
4. **Remove Licenses**: Unassigns all Microsoft 365 licenses
5. **Remove Groups**: Clears all group memberships
6. **Remove Apps**: Revokes app registrations and device access

#### Exchange Online (If mailbox exists)
1. **Mailbox Check**: Verifies user has Exchange license
2. **Auto-Reply**: Configures Out-of-Office message:
   ```
   [Employee Name] is no longer with the company.
   For assistance, please contact [Manager Name] at [Manager Email].
   ```
3. **Convert to Shared**: Changes mailbox type to shared (retains 30 days)
4. **Assign Delegates**: Grants manager full access

### Example Scenarios

#### Scenario 1: Hybrid User (AD + Entra ID)
```powershell
Input: john.doe
Account Type: Hybrid (AD-synced)
Operations:
- AD: Disable, reset password, move OU, remove groups
- Entra ID: Disable, revoke sessions, remove licenses, remove apps
- Exchange: Set auto-reply, convert to shared mailbox
Result: User fully offboarded, mailbox accessible to manager
```

#### Scenario 2: Cloud-Only User (Entra ID Only)
```powershell
Input: jane.smith@contoso.onmicrosoft.com
Account Type: Cloud-Only (No AD account)
Operations:
- Entra ID: Disable, revoke sessions, remove licenses, remove apps
- Exchange: Set auto-reply, convert to shared mailbox
Skipped: AD operations (user not in Active Directory)
Result: Cloud user fully offboarded
```

#### Scenario 3: On-Premises Only
```powershell
Input: bob.jones
Account Type: On-Premises (Not synced to Entra ID)
Operations:
- AD: Disable, reset password, move OU, remove groups
Skipped: Entra ID operations (user not synced)
Result: On-premises AD user disabled
```

---

## 📋 Bulk Termination

### CSV File Format

#### Required Columns (choose one)
- **sAMAccountName**: AD username (e.g., `john.doe`)
- **UPN**: User Principal Name (e.g., `john.doe@contoso.com`)
- **EmailAddress**: Email address (e.g., `john.doe@contoso.com`)

#### Optional Columns
- **AutoReplyMessage**: Custom Out-of-Office message
- **DelegateEmail**: Manager email for mailbox access

### CSV Examples

#### Example 1: Hybrid Users (sAMAccountName)
```csv
sAMAccountName,AutoReplyMessage,DelegateEmail
john.doe,"John Doe is no longer with the company. Contact HR.",manager@contoso.com
jane.smith,,hr@contoso.com
```

#### Example 2: Cloud-Only Users (UPN)
```csv
UPN,AutoReplyMessage
cloud.user1@contoso.onmicrosoft.com,"User has left the company."
cloud.user2@contoso.onmicrosoft.com,
```

#### Example 3: Mixed Format (Email Address)
```csv
EmailAddress,DelegateEmail
john.doe@contoso.com,manager1@contoso.com
jane.smith@contoso.com,manager2@contoso.com
```

### Bulk Termination Process

#### Step 1: Prepare CSV File
1. Use included template: `BulkTemplate.csv`
2. Or see examples in `Examples\` folder:
   - `CloudOnlyUsers.csv`
   - `HybridUsers.csv`
3. Save with UTF-8 encoding

#### Step 2: Load CSV in ADATT
1. Click **"Load CSV"** button
2. Select your CSV file
3. ADATT performs user lookups:
   - Searches Active Directory first (hybrid/on-premises)
   - Falls back to Entra ID (cloud-only users)
   - Shows progress: "Processing user 5 of 20..."

#### Step 3: Review User Grid
Preview grid displays:
- **Display Name**: User's full name
- **UPN**: User Principal Name
- **Account Type**: Cloud-Only, Hybrid, On-Premises
- **Status**: Found / Not Found

**Color Coding**:
- 🟢 **Green**: User found successfully
- 🔴 **Red**: User not found (check username)

#### Step 4: Execute Bulk Termination
1. Click **"Bulk Offboard"** button
2. Confirmation prompt: "Terminate 20 users?"
3. Click **"Yes"**
4. Progress updates: "Terminating user 5 of 20..."
5. Completion: "Bulk termination completed"

#### Step 5: Review Results
Check **Reports** folder:
- File: `BulkTermination_Report_YYYYMMDD_HHMMSS.csv`
- Columns:
  - `DisplayName`: User's full name
  - `UPN`: User Principal Name
  - `AccountType`: Cloud-Only, Hybrid, On-Premises
  - `Status`: Success / Failed
  - `ErrorMessage`: Details (if failed)
  - `Timestamp`: Operation completion time

### Bulk Performance

| Users | Time (v1.5.0) | Time (v1.4.x) |
|-------|---------------|---------------|
| 10    | 8-10 seconds  | 50 seconds    |
| 50    | 40-50 seconds | 4+ minutes    |
| 100   | 90-120 seconds| 8+ minutes    |

**Optimization**: v1.5.0 uses batch queries for mailbox checks (5x faster)

---

## 🔐 Reset MFA

### When to Use
- User locked out of MFA
- Lost phone/authenticator app
- Emergency access needed

### Reset Process

#### Step 1: Enter Username
In **"Reset MFA"** section:
- Enter: `sAMAccountName` or `UPN`
- Examples: `john.doe` or `john.doe@contoso.com`

#### Step 2: Click "Reset MFA"
ADATT performs:
1. User lookup (AD or Entra ID)
2. Retrieves MFA authentication methods
3. Deletes all registered methods:
   - Mobile phone
   - Authenticator app
   - Software tokens
   - Hardware keys

#### Step 3: Confirm Success
Message: "MFA reset for [User Name]"

### User Next Steps
1. User signs in with password
2. Prompted to re-register MFA
3. Follows MFA setup wizard

### Supported Account Types
- ✅ Hybrid users (AD-synced)
- ✅ Cloud-only users (Entra ID)
- ❌ On-premises only (requires Entra ID)

---

## 🚪 Sign Out Sessions

### When to Use
- Force user to re-authenticate
- Security incident response
- Before account termination

### Process

#### Step 1: Enter Username
In **"Sign Out Sessions"** section:
- Enter: `sAMAccountName` or `UPN`

#### Step 2: Click "Sign Out Sessions"
ADATT performs:
1. User lookup (Entra ID required)
2. Revokes all active refresh tokens
3. Signs out from:
   - Web browsers
   - Mobile apps
   - Desktop applications
   - Outlook, Teams, OneDrive, etc.

#### Step 3: Confirm Success
Message: "All sessions revoked for [User Name]"

### Session Revocation Scope
- **Immediate**: Current active sessions terminated
- **Future**: Refresh tokens invalidated
- **Devices**: All devices forced to re-authenticate

---

## 🏷️ Account Types

ADATT automatically detects three account types:

### 1. Hybrid (AD + Entra ID)
**Description**: User exists in both Active Directory and Entra ID (synced via Azure AD Connect)

**Detection Method**:
- Found in Active Directory
- Has matching Entra ID account (by UPN)

**Operations Supported**:
- ✅ All Active Directory operations
- ✅ All Entra ID operations
- ✅ Exchange Online operations
- ✅ MFA reset
- ✅ Session revocation

**Example Users**:
- Corporate employees with domain-joined PCs
- Users with AD accounts synced to Microsoft 365

### 2. Cloud-Only (Entra ID Only)
**Description**: User exists only in Microsoft Entra ID (no Active Directory account)

**Detection Method**:
- Not found in Active Directory
- Found in Entra ID

**Operations Supported**:
- ❌ Active Directory operations (skipped)
- ✅ All Entra ID operations
- ✅ Exchange Online operations
- ✅ MFA reset
- ✅ Session revocation

**Example Users**:
- External contractors with M365 licenses
- Cloud-native organizations without AD
- Guest users with full accounts

### 3. On-Premises (AD Only)
**Description**: User exists only in Active Directory (not synced to Entra ID)

**Detection Method**:
- Found in Active Directory
- Not found in Entra ID

**Operations Supported**:
- ✅ All Active Directory operations
- ❌ Entra ID operations (skipped)
- ❌ Exchange Online operations (skipped)

**Example Users**:
- Users in non-synced OUs
- Legacy accounts not migrated to cloud
- Test accounts in isolated AD environments

---

## 📊 Reports and Logs

### Report Files

#### Single Termination
**Location**: `Reports\Termination_Report_YYYYMMDD_HHMMSS.csv`

**Columns**:
```csv
DisplayName,UPN,AccountType,OperationsPerformed,Status,Timestamp
John Doe,john.doe@contoso.com,Hybrid,"AD Disabled, Graph Cleanup, Mailbox Converted",Success,2026-01-08 10:30:45
```

#### Bulk Termination
**Location**: `Reports\BulkTermination_Report_YYYYMMDD_HHMMSS.csv`

**Columns**:
```csv
DisplayName,UPN,AccountType,Status,ErrorMessage,Timestamp
John Doe,john.doe@contoso.com,Hybrid,Success,,2026-01-08 10:30:45
Jane Smith,jane.smith@contoso.com,Cloud-Only,Success,,2026-01-08 10:31:12
Bob Jones,bob.jones@contoso.com,Unknown,Failed,User not found,2026-01-08 10:31:45
```

### Transcript Logs

**Location**: `Transcripts\ADATT_Transcript_YYYYMMDD_HHMMSS.log`

**Content**:
- Detailed PowerShell execution log
- All commands executed
- API responses
- Error messages with stack traces
- Timestamps for each operation

**Example Excerpt**:
```
[2026-01-08 10:30:45] INFO: Starting termination for john.doe
[2026-01-08 10:30:46] INFO: User found in Active Directory
[2026-01-08 10:30:47] INFO: User found in Entra ID (Hybrid account detected)
[2026-01-08 10:30:48] SUCCESS: AD account disabled
[2026-01-08 10:30:50] SUCCESS: Entra ID account disabled
[2026-01-08 10:30:55] SUCCESS: Mailbox converted to shared
[2026-01-08 10:30:56] INFO: Termination completed successfully
```

---

## ✅ Best Practices

### Before Termination
1. ✅ **Verify username/UPN is correct**
2. ✅ **Identify manager for mailbox delegation**
3. ✅ **Backup critical data (if needed)**
4. ✅ **Check for shared mailboxes/resources user owns**
5. ✅ **Review group memberships (especially distribution lists)**

### During Termination
1. ✅ **Use confirmation dialog** - Review operations before confirming
2. ✅ **Monitor progress** - Watch for errors in real-time
3. ✅ **Check transcript log** - Review detailed operations
4. ✅ **Verify mailbox conversion** - Confirm manager can access

### After Termination
1. ✅ **Review CSV report** - Check Status column for failures
2. ✅ **Test mailbox access** - Manager should access shared mailbox
3. ✅ **Verify auto-reply** - Send test email to terminated user
4. ✅ **Check group memberships** - Confirm user removed from sensitive groups
5. ✅ **Audit log review** - Check Microsoft 365 audit logs

### Bulk Termination Tips
1. ✅ **Test with 1-2 users first** - Validate CSV format
2. ✅ **Use incremental batches** - Process 20-50 users at a time
3. ✅ **Schedule during off-hours** - Minimize API throttling
4. ✅ **Have rollback plan** - Know how to re-enable if needed
5. ✅ **Communicate with managers** - Notify before mailbox conversion

---

## 🐛 Troubleshooting

### Issue: "User not found"
**Causes**:
- Incorrect username/UPN
- User already deleted
- Cloud-only user entered as sAMAccountName

**Solutions**:
1. Verify username spelling
2. Try UPN format instead: `user@domain.com`
3. Check Active Directory Users and Computers
4. Search Entra ID admin center

### Issue: "Mailbox not found"
**Cause**: User doesn't have Exchange Online license

**Solution**: ADATT automatically skips mailbox operations (v1.5.0+)

### Issue: "Graph API authentication failed"
**Causes**:
- Token expired
- Insufficient permissions
- Network connectivity

**Solutions**:
1. Re-authenticate: Click any Graph operation
2. Verify admin role: User Administrator or Global Admin
3. Check network: Firewall allows `https://graph.microsoft.com`
4. Clear cached credentials: `Disconnect-MgGraph`

### Issue: "Exchange Online connection failed"
**Causes**:
- Credentials incorrect
- MFA timeout
- Exchange role not assigned

**Solutions**:
1. Re-connect: `Connect-ExchangeOnline`
2. Verify role: Exchange Administrator
3. Try basic auth: `Connect-ExchangeOnline -UserPrincipalName admin@domain.com`

### Issue: Bulk CSV "0 users found"
**Causes**:
- CSV encoding issue (not UTF-8)
- Missing required column (sAMAccountName, UPN, or EmailAddress)
- Column header misspelled

**Solutions**:
1. Save CSV as UTF-8 encoding
2. Use provided template: `BulkTemplate.csv`
3. Verify column headers exactly match:
   - `sAMAccountName` (case-sensitive)
   - `UPN` (case-sensitive)
   - `EmailAddress` (case-sensitive)

### Issue: "License activation failed"
**Causes**:
- Invalid license key format
- License already activated on another device
- No internet connectivity

**Solutions**:
1. Verify key format: `XXXX-XXXX-XXXX-XXXX`
2. Deactivate on old device first
3. Run: `.\clear-license.ps1` then re-activate
4. Check internet: `Test-NetConnection lemonsqueezy.com -Port 443`

---

## 📞 Support and Resources

### Quick Reference
- **Start Here**: [START_HERE.md](START_HERE.md)
- **Installation**: [INSTALLATION.md](INSTALLATION.md)
- **Technical Docs**: [README.md](README.md)
- **Version Info**: [VERSION_INFO.txt](VERSION_INFO.txt)

### Templates and Examples
- **Bulk Template**: `BulkTemplate.csv`
- **Cloud-Only Example**: `Examples\CloudOnlyUsers.csv`
- **Hybrid Example**: `Examples\HybridUsers.csv`

### Utilities
- **Prerequisites Check**: `.\test-prerequisites.ps1`
- **License Reset**: `.\clear-license.ps1`

### Contact Support
- **Email**: adatt@unifosec.com
- **Purchase License**: https://adatt.lemonsqueezy.com
- **Documentation**: Included in this package

---

## 🎯 Quick Reference Card

### Single Termination
```powershell
1. Launch: .\ADATT-UX.ps1
2. Enter: username or UPN
3. Click: Terminate
4. Review: Confirmation dialog
5. Confirm: Yes, Terminate
6. Check: Reports folder
```

### Bulk Termination
```powershell
1. Create: CSV with sAMAccountName/UPN column
2. Click: Load CSV
3. Review: User grid (verify green rows)
4. Click: Bulk Offboard
5. Confirm: Yes
6. Check: BulkTermination_Report.csv
```

### Reset MFA
```powershell
1. Enter: username
2. Click: Reset MFA
3. Notify: User to re-register on next login
```

### Sign Out Sessions
```powershell
1. Enter: username
2. Click: Sign Out Sessions
3. Verify: User forced to re-authenticate
```

---

**Happy Offboarding!** 🚀

---

**Version**: 1.5.0  
**Release Date**: January 2026  
**Author**: Jose Ernest  
**Company**: Unifosec  

© 2025-2026 Jose Ernest / Unifosec. All rights reserved.
