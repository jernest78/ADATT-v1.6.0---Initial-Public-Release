# 🚀 START HERE - ADATT v1.5.0

**ADATT** (Active Directory + Azure/M365 Termination Tool)  
**Automated Employee Offboarding Tool for Hybrid Environments**

---

## 📋 Quick Start

### 1️⃣ **Check Prerequisites**
Run this command to verify your system is ready:
```powershell
.\test-prerequisites.ps1
```

### 2️⃣ **Activate Your License**
- Launch ADATT: `.\ADATT-UX.ps1`
- Click **"Activate License"** button
- Enter your license key from LemonSqueezy
- Click **Activate**

### 3️⃣ **Start Offboarding**
Choose your method:
- **Single User**: Enter sAMAccountName or UPN → Click "Terminate"
- **Bulk**: Load CSV file → Review users → Click "Bulk Offboard"
- **Reset MFA**: Enter username → Click "Reset MFA"

---

## 🎯 What's New in v1.5.0

### ✨ Major Features
- **Cloud-Only Entra ID Support** - Offboard users without AD accounts
- **Intelligent Mailbox Detection** - Auto-skip users without Exchange licenses
- **Termination Confirmation Dialog** - Shows account type and planned operations
- **Batch Mailbox Optimization** - 5x faster for 10+ users (8-10s vs 50s)
- **Account Type Tracking** - CSV reports show Cloud-Only/Hybrid/On-Premises

### 🚀 Performance Improvements
- Exponential backoff retry logic for Graph API throttling
- Automatic batch queries for large-scale operations
- Multi-strategy user lookup (UPN, email, mailNickname)

### 🐛 Bug Fixes
- Cloud-only users no longer show "User not found in AD" error
- Mailbox operations properly skipped for users without licenses
- Bulk termination handles all account types without errors
- Reset MFA and Sign Out Sessions work with cloud-only users

---

## 📚 Important Files

| File | Purpose |
|------|---------|
| **ADATT-UX.ps1** | Main application - double-click to launch |
| **INSTALLATION.md** | Detailed installation and setup instructions |
| **GUIDE.md** | Complete usage guide with examples |
| **README.md** | Full technical documentation |
| **BulkTemplate.csv** | Template for bulk terminations |
| **clear-license.ps1** | Reset license activation (for testing) |
| **test-prerequisites.ps1** | Verify system requirements |

---

## ⚡ Quick Examples

### Single User Termination
```powershell
1. Launch: .\ADATT-UX.ps1
2. Enter: john.doe (or john.doe@contoso.com)
3. Click: Terminate
4. Confirm: Review operations → Click "Yes, Terminate"
```

### Bulk Termination
```powershell
1. Create CSV with columns: sAMAccountName, UPN, or EmailAddress
2. Launch ADATT → Click "Load CSV"
3. Review users in preview grid
4. Click "Bulk Offboard"
5. Check Reports folder for results
```

### Reset MFA
```powershell
1. Launch ADATT
2. Enter username in Reset MFA field
3. Click "Reset MFA"
4. User can re-register MFA on next login
```

---

## 🔧 Supported Account Types

| Type | Description | Features Supported |
|------|-------------|-------------------|
| **Hybrid** | AD-synced to Entra ID | All features (AD + Exchange + Graph) |
| **Cloud-Only** | Entra ID only (no AD) | Exchange + Graph operations |
| **On-Premises** | AD only (not synced) | AD operations only |

---

## 🆘 Need Help?

- **Installation Issues**: See [INSTALLATION.md](INSTALLATION.md)
- **Usage Questions**: See [GUIDE.md](GUIDE.md)
- **Technical Details**: See [README.md](README.md)
- **License Problems**: Run `.\clear-license.ps1` then re-activate
- **Prerequisites**: Run `.\test-prerequisites.ps1`

---

## 🎫 License Information

This software requires a valid license:
- **7-Day Trial**: Available immediately after installation
- **Solo Admin**: 1 device license
- **Team**: 5 devices license
- **Business**: 20 devices license

Purchase at: **https://adatt.lemonsqueezy.com**

---

## 📞 Support

- **Email**: adatt@unifosec.com
- **Documentation**: Full guide included in this package
- **License Issues**: Use "Activate License" button in ADATT

---

**Version**: 1.5.0  
**Release Date**: January 2026  
**Author**: Jose Ernest  
**Company**: Unifosec  

© 2025-2026 Jose Ernest / Unifosec. All rights reserved.
